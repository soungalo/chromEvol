#include "generalGammaDistributionPlusInvariant.h"




//#define RATE_INVARIANT 1e-8 //1e-10







