// $Id: suffStatComponent.cpp 962 2006-11-07 15:13:34Z privmane $

#include "suffStatComponent.h"



