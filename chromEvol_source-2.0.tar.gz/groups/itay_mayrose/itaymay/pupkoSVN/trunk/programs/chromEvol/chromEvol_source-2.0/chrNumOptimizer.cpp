#include "chrNumOptimizer.h"
#include "chrNumModel.h"
#include "logFile.h"
#include "chrNumberOptions.h"
#include "numRec.h"
#include "evalParamChrNum.h"
#include "chrNumberMng.h"
#include <algorithm>
using namespace std;

chrNumOptimizer::chrNumOptimizer(const tree &tr, const sequenceContainer &sc)
:_tree(tr), _sc(sc)
{
}

chrNumOptimizer::~chrNumOptimizer()
{}

MDOUBLE chrNumOptimizer::optimizeModel(stochasticProcess* pSp, MDOUBLE epsilonLLImprovement, int maxIter, MDOUBLE tolParamOptimization)
{
	chrNumModel* pModel = static_cast<chrNumModel*>(pSp->getPijAccelerator()->getReplacementModel());
	if (pModel->getScaleFactor() != IGNORE_PARAM)
		return optimizeCombinedSpeciationalModel(pSp, epsilonLLImprovement, maxIter, tolParamOptimization);


	cerr<<"+++++++++++++++++++++++++++++++++++++++++"<<endl;
	LOG(3, <<"starting optimization:"<<endl;); 
	LOGDO(5, pModel->printModelParams(myLog::LogFile())); 

	vector<paramObj> paramVec;
	_bestL = chrNumberMng::compLogLikelihood(pSp, _tree, _sc, chrNumberOptions::_rootFreqType);
	LOG(5, <<"ll before optimization = "<<_bestL<<endl;);

	MDOUBLE prevIterL = VERYSMALL;
	int iter;
	for (iter = 0; iter < maxIter; ++iter) 
	{
        if (_bestL < prevIterL + epsilonLLImprovement)
			return _bestL; //likelihood converged
		//optimize exon free params
		prevIterL = _bestL;
		pModel->getOptimizedParams(paramVec); 
		LOG(3,<<"iteration: "<<iter<<" begin"<<endl;);
		for(int p = 0; p < paramVec.size(); ++p) {
			MDOUBLE paramFound;
			string paramName = pModel->getParamName(paramVec[p]._type);
			LOG(3,<<"optmizing "<<paramName<<endl;);
			MDOUBLE newL;
            MDOUBLE lowerBound = pModel->getParamLowerBound(paramVec[p]._type);
			MDOUBLE upperBound = pModel->getParamUpperBound(paramVec[p]._type);
			newL = -brent(lowerBound, paramVec[p]._value, upperBound, evalParamChrNum(pSp, _tree, _sc, paramVec[p]._type, chrNumberOptions::_rootFreqType),tolParamOptimization, &paramFound); 	

            if (DBIG_EQUAL(newL, _bestL) )
			{
                _bestL = newL;
                pModel->setParam(paramFound, paramVec[p]._type);
			}
            else
			{//likelihood went down!
				LOG(3,<<"inside chrNumOptimizer::optimizeModel"<<endl;);
				LOG(3,<<"like went down when optimizing: "<<paramName<<endl;);
				LOG(3,<<"param Found = "<<paramFound<<"   LL ="<<newL<<"..."<<endl;);
				LOG(3,<<"param  old = "<<paramVec[p]._value<<"   LL="<<_bestL<<"..."<<endl;);
				LOGDO(3, pModel->printModelParams(myLog::LogFile())); 
				LOGDO(3, pModel->printQmatrix(myLog::LogFile())); 

				pModel->setParam(paramVec[p]._value, paramVec[p]._type);
				errorMsg::reportError("lL went down!!!");
			}
            LOG(3,<<" LL= "<<_bestL<<" new = "<<paramFound<<" old="<<paramVec[p]._value<<endl;);
		}
	}
	if (chrNumberOptions::_rootFreqType == chrNumModel::ROOT_LL)
	{
		//the freqs should be adjusted to the current model parameters since it is not gurantee that the last LL computation is for the best params
		MDOUBLE xx = chrNumberMng::compLogLikelihood(pSp, _tree, _sc, chrNumberOptions::_rootFreqType);
		if (! DEQUAL(xx, _bestL, 0.000001))
			errorMsg::reportError("error in LL computations");

	}
	return _bestL;
}

MDOUBLE chrNumOptimizer::optimizeModelManyStart(stochasticProcess* pSp, const Vint& pointsNum, const Vint& iterNum, const Vdouble& tols)
{
	//make sure that the number of points in each cycle is not bigger than the previous cycle.
	int i;
	for (i = 0; i < pointsNum.size()-1; ++i) {
		if (pointsNum[i] < pointsNum[i+1])
			errorMsg::reportError("input error in chrNumOptimizer::optimizeModelManyStart()");
	}
	//create starting models
	vector<stochasticProcess*> spVec;
	for (int i = 0; i < pointsNum[0]; ++i)
	{
		//the first model is identical to the current one
		if (i == 0)
			spVec.push_back(pSp->clone());
		else
			spVec.push_back(getRandomProcess(pSp)); 
		//LOGDO(5, static_cast<chrNumModel*>(spVec[i]->getPijAccelerator()->getReplacementModel())->printModelParams(myLog::LogFile())); 
	}
	
	int numOfOptCycles = pointsNum.size();
	Vdouble likelihoodVec;
	for (int n = 0; n < numOfOptCycles; ++n)
	{
		LOG(5, <<"=====Cycle======= " <<n<<endl;);
		if (n != 0)
		{
			//sort results and continue optimization only with the best (pointsNum[i]) points
			vector<stochasticProcess*> tmpSpVec(0); //store temporarily the best pointsNum[i] sp* 
			Vdouble sortedL = likelihoodVec;
			sort(sortedL.begin(),sortedL.end());
			MDOUBLE threshold = sortedL[sortedL.size()- pointsNum[n]];
			for (int j = 0; j < likelihoodVec.size(); ++j)
			{
				if (likelihoodVec[j] >= threshold) 
					tmpSpVec.push_back(spVec[j]);
				else
					delete spVec[j];
			}
			spVec.clear();
			spVec = tmpSpVec;
		} 

		likelihoodVec.clear();
		likelihoodVec.resize(pointsNum[n]); 
		for (int c = 0; c < pointsNum[n]; ++c)
		{
			LOG(3, <<"=====optimizing point======= " <<c<<endl;);
			stochasticProcess* ptempSp = spVec[c];
			MDOUBLE ll = optimizeModel(spVec[c], tols[n], iterNum[n], tols[n]);
			LOG(3, <<"point: "<<c<<"  likelihood = "<<ll<<endl<<endl;);
			likelihoodVec[c] = ll;
		}
	}
	//finish optimization - get best model
	Vdouble sortedL = likelihoodVec;
	sort(sortedL.begin(),sortedL.end());
	MDOUBLE _bestL = sortedL[likelihoodVec.size() - 1];
	LOG(3, <<endl<<"FINAL LIKELIHOODS++++++++++++++"<<endl;);
	for (int i = 0; i < likelihoodVec.size(); ++i)
	{
		if (_bestL == likelihoodVec[i]) 
		{
			//this operator= delete the current pointers of pSp and clone new ones
			*pSp = *spVec[i];
		}
		delete spVec[i];
		spVec[i] = NULL;
		LOG(chrNumberOptions::_logValue, <<"point "<<i<<" likelihood = "<<likelihoodVec[i]<<endl;);
		
	}	
	spVec.clear();
	return _bestL;
}



stochasticProcess* chrNumOptimizer::getRandomProcess(const stochasticProcess* pBaseSp) const
{
	stochasticProcess* pRes = pBaseSp->clone();
	static_cast<chrNumModel*>(pRes->getPijAccelerator()->getReplacementModel())->setRandomRateParams(true);
	return pRes;
}

MDOUBLE chrNumOptimizer::optimizeCombinedSpeciationalModel(stochasticProcess* pSp, MDOUBLE epsilonLLImprovement, int maxIter, MDOUBLE tolParamOptimization)
{
	chrNumModel* pModel = static_cast<chrNumModel*>(pSp->getPijAccelerator()->getReplacementModel());
	//first scale tree
	tree myTree(_tree);
	chrNumberMng::scaleTree(myTree, pModel->getScaleFactor());

	cerr<<"+++++++++++++++++++++++++++++++++++++++++"<<endl;
	LOG(3, <<"starting optimization:"<<endl;); 
	LOGDO(5, pModel->printModelParams(myLog::LogFile())); 

	vector<paramObj> paramVec;
	_bestL = chrNumberMng::compLogLikelihood(pSp, myTree, _sc, chrNumberOptions::_rootFreqType);
	LOG(5, <<"ll before optimization = "<<_bestL<<endl;);

	MDOUBLE prevIterL = VERYSMALL;
	int iter;
	for (iter = 0; iter < maxIter; ++iter) 
	{
        if (_bestL < prevIterL + epsilonLLImprovement)
			return _bestL; //likelihood converged
		//optimize exon free params
		prevIterL = _bestL;
		pModel->getParams(paramVec); 
		LOG(3,<<"iteration: "<<iter<<" begin"<<endl;);
		for(int p = 0; p < paramVec.size(); ++p) {
			MDOUBLE paramFound;
			string paramName = pModel->getParamName(paramVec[p]._type);
			LOG(3,<<"optmizing "<<paramName<<endl;);
			MDOUBLE newL;
            MDOUBLE lowerBound = pModel->getParamLowerBound(paramVec[p]._type);
			MDOUBLE upperBound = pModel->getParamUpperBound(paramVec[p]._type);
			if (paramVec[p]._type == SCALE_BRANCH)
			{
				newL = -brent(lowerBound, paramVec[p]._value, upperBound, evalParamSpeciationalProp(pSp, _tree, _sc, paramVec[p]._type, chrNumberOptions::_rootFreqType),tolParamOptimization, &paramFound); 	
				myTree = _tree;
				chrNumberMng::scaleTree(myTree, paramFound);
			}
			else 
			{
				newL = -brent(lowerBound, paramVec[p]._value, upperBound, evalParamChrNum(pSp, myTree, _sc, paramVec[p]._type, chrNumberOptions::_rootFreqType),tolParamOptimization, &paramFound); 	
			}
			if (newL >= _bestL) 
			{
				_bestL = newL;
				pModel->setParam(paramFound, paramVec[p]._type);
			}
            else
			{//likelihood went down!
				LOG(3,<<"inside chrNumOptimizer::optimizeCombinedSpeciationalModel"<<endl;);
				LOG(3,<<"like went down when optimizing: "<<paramName<<endl;);
				LOG(3,<<"param Found = "<<paramFound<<"   LL ="<<newL<<"..."<<endl;);
				LOG(3,<<"param  old = "<<paramVec[p]._value<<"   LL="<<_bestL<<"..."<<endl;);
				LOGDO(3, pModel->printModelParams(myLog::LogFile())); 
				LOGDO(3, pModel->printQmatrix(myLog::LogFile())); 
				if (paramVec[p]._type == SCALE_BRANCH) {
					myTree = _tree;
					chrNumberMng::scaleTree(myTree, paramVec[p]._value);
				}
				pModel->setParam(paramVec[p]._value, paramVec[p]._type);
				errorMsg::reportError("lL went down!!!");
			}
            LOG(3,<<" LL= "<<_bestL<<" new = "<<paramFound<<" old="<<paramVec[p]._value<<endl;);
		}
	}
	if (chrNumberOptions::_rootFreqType == chrNumModel::ROOT_LL)
	{
		//the freqs should be adjusted to the current model parameters since it is not gurantee that the last LL computation is for the best params
		MDOUBLE xx = chrNumberMng::compLogLikelihood(pSp, myTree, _sc, chrNumberOptions::_rootFreqType);
		if (xx != _bestL)
			errorMsg::reportError("error in LL computations");
	}
	return _bestL;
}


//MDOUBLE chrNumOptimizer::optimizeModel_GD(stochasticProcess* pSp, MDOUBLE epsilonLLImprovement, int maxIter, MDOUBLE tolParamOptimization)
//{
//	chrNumModel* pModel = static_cast<chrNumModel*>(pSp->getPijAccelerator()->getReplacementModel());
//
//	cerr<<"+++++++++++++++++++++++++++++++++++++++++"<<endl;
//	LOG(3, <<"starting optimization:"<<endl;); 
//	LOGDO(5, pModel->printModelParams(myLog::LogFile())); 
//
//	_bestL = chrNumberMng::compLogLikelihood(pSp, _tree, _sc, chrNumberOptions::_rootFreqType);
//	LOG(5, <<"ll before optimization = "<<_bestL<<endl;);
//
//	stochasticProcess leftSp = *pSp;
//	stochasticProcess rightSp = *pSp;
//
//	MDOUBLE prevIterL = VERYSMALL;
//	vector<MDOUBLE> gradient;
//	int iter;
//	bool hit_the_edge = false;
//	for (iter = 0; iter < maxIter; ++iter) 
//	{
//        if ((_bestL < prevIterL + epsilonLLImprovement) && !hit_the_edge) 
//			return _bestL; //likelihood converged
//		hit_the_edge = true; // so the next iteration will have to change it back ??but why did we initialize with false?
//		prevIterL = _bestL;
//
//		LOG(3,<<"iteration: "<<iter<<" begin"<<endl;);
//		vector<paramObj> paramLeft, paramRight;
//		static_cast<chrNumModel*>(leftSp.getPijAccelerator()->getReplacementModel())->getOptimizedParams(paramLeft);  //we should not get baseNUmber!!
//		find_gradient(paramLeft, _bestL, &leftSp, tolParamOptimization, gradient);
//		chrNumModel* pRightModel = static_cast<chrNumModel*>(rightSp.getPijAccelerator()->getReplacementModel());
//		pRightModel->getOptimizedParams(paramRight);
//		for(int p = 0; p < paramRight.size(); ++p) {
//			MDOUBLE newVal = paramRight[p]._value + gradient[p];
//			pRightModel->setParam(newVal, paramRight[p]._type); //should make sure newVal is non-negative
//		}
//		MDOUBLE leftPointLikelihood = _bestL;
//		string valid = "left";
//
//		while (getDistance(&rightSp, &leftSp) > tolParamOptimization) {
//			gradient_walk_step(leftSp, rightSp, 
//		}
//
//        //print new params to log
//		//LOG(3,<<" LL= "<<_bestL<<" new = "<<paramFound<<" old="<<paramVec[p]._value<<endl;);
//	}
//	
//	if (chrNumberOptions::_rootFreqType == chrNumModel::ROOT_LL)
//	{
//		//the freqs should be adjusted to the current model parameters since it is not gurantee that the last LL computation is for the best params
//		MDOUBLE xx = chrNumberMng::compLogLikelihood(pSp, _tree, _sc, chrNumberOptions::_rootFreqType);
//		if (! DEQUAL(xx, _bestL, 0.000001))
//			errorMsg::reportError("error in LL computations");
//
//	}
//	return _bestL;
//}
//
//calcualte the middle point between left and right. Then set the middle point to the left/right according to the point with lower likelihood 
//Valid: tells whether the left or right was caluclated before (so if middle was set to the right then the "new right" should be calcualted again and so only left is valid
void chrNumOptimizer::gradient_walk_step(vector<paramObj>& paramLeft, vector<paramObj>& paramRight, const stochasticProcess* pSp, MDOUBLE &left_likelihood, MDOUBLE &right_likelihood, string &valid) {
	//have to make sure that the pSp that is used here does not change the pSp that was called
	stochasticProcess sp = *pSp;
	chrNumModel* pModel = static_cast<chrNumModel*>(sp.getPijAccelerator()->getReplacementModel());
	vector<paramObj> middlePoint = paramLeft;
	if(valid != "left")
	{
		for (int p = 0; p < paramLeft.size(); ++p) {
			pModel->setParam(paramLeft[p]._value, paramLeft[p]._type);
		}
		left_likelihood = chrNumberMng::compLogLikelihood(&sp, _tree, _sc, chrNumberOptions::_rootFreqType);
	}
	if(valid != "right")
	{
		for (int p = 0; p < paramRight.size(); ++p) {
			pModel->setParam(paramRight[p]._value, paramRight[p]._type);
		}
		left_likelihood = chrNumberMng::compLogLikelihood(&sp, _tree, _sc, chrNumberOptions::_rootFreqType);
	}
	for(int p = 0; p < paramRight.size(); ++p)
	{
		middlePoint[p]._value = ((paramRight[p]._value + paramLeft[p]._value)/2);	
	}

	if(left_likelihood > right_likelihood)
	{
		paramRight = middlePoint;
		valid = "left";
	}
	else
	{
		paramLeft = middlePoint;
		valid = "right";
	}
}

void chrNumOptimizer::find_gradient(vector<paramObj>& paramVec, MDOUBLE curL, const stochasticProcess* pSp, MDOUBLE epsilon, vector<MDOUBLE>& gradient) {
	stochasticProcess sp = *pSp;
	chrNumModel* pModel = static_cast<chrNumModel*>(sp.getPijAccelerator()->getReplacementModel());
	MDOUBLE size = 1000/epsilon; 
	MDOUBLE temp_size = 1000/epsilon;

	for (int p = 0; p < paramVec.size(); ++p) {
		MDOUBLE lowerBound = pModel->getParamLowerBound(paramVec[p]._type);
		MDOUBLE upperBound = pModel->getParamUpperBound(paramVec[p]._type);

		MDOUBLE origVal = paramVec[p]._value;
		MDOUBLE newVal = origVal + epsilon;
		pModel->setParam(newVal, paramVec[p]._type);
		MDOUBLE tempL = chrNumberMng::compLogLikelihood(&sp, _tree, _sc, chrNumberOptions::_rootFreqType);
		if ((tempL>curL && newVal>upperBound) || (tempL<curL && newVal<lowerBound)) {//so we won't go off the edge
			gradient.push_back(0);
		}
		else {
			MDOUBLE grad = (tempL-curL)/epsilon;
			gradient.push_back(grad); 
			if (grad > 0)
				temp_size = (upperBound-origVal)/grad;
			if (grad < 0)
				temp_size = (lowerBound-origVal)/grad;
			if(temp_size<size && temp_size>0)
				size = temp_size;


		}
		pModel->setParam(origVal, paramVec[p]._type);
	}
	if (paramVec.size() != gradient.size())
		errorMsg::reportError("error in find_gradient: the paramVec must be the same size as gradientVec");
	//resize gradient
	for (int p = 0; p < paramVec.size(); ++p) {
		gradient[p] = gradient[p]*size;
	}
}

MDOUBLE chrNumOptimizer::getDistance(const vector<paramObj>& paramLeft, const vector<paramObj>& paramRight) {
	int dimension = paramLeft.size();
	MDOUBLE dist=0;
	for(int i=0; i < dimension; ++i){
		dist += pow(paramLeft[i]._value - paramRight[i]._value,2);
	}
	dist=sqrt(dist);
	return dist;
}
